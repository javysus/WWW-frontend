const ejemplares_reservados = {
    "data": {
      "getEjemplaresByEstado": [
        {
          "id": "633671542436056ff7585878",
          "estado": "Reservado"
        },
        {
          "id": "6336717c2436056ff758587c",
          "estado": "Reservado"
        }
      ]
    }
  }

export default ejemplares_reservados;