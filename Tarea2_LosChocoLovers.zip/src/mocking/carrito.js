const carrito = {
    "data": {
      "getCarrito": [
        {
          "id_libro": "633670ca2436056ff7585875",
          "titulo": "PRINCIPITO, EL",
          "autor": "DE SAINT-EXUPERY, ANTOINE",
          "tipo": "Libro",
          "lugar": "En sala",
          "fecha_devolucion": "26/11/2022",
        },
        {
            "id_libro": "643670ca2436056ff7585877",
            "titulo": "EL LIBRO TROLL",
            "autor": "EL RUBIUS",
            "tipo": "Libro",
            "lugar": "En sala",
            "fecha_devolucion": "17/11/2022",
        }
      ]
    }
  }

  export default carrito;