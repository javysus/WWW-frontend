const prestamos = {
    "data": {
      "getPrestamosByBibliotecario": [
        {
          "fecha_prestamo": "2022-09-30T05:18:00.000Z",
          "fecha_devolucion": "2022-10-15T05:18:00.000Z",
          "fecha_devol_real": "2022-10-16T05:03:25.857Z",
          "lugar": "Casa",
          "ejemplar": {
            "id": "633671542436056ff7585878"
          },
          "comprobante": null,
          "usuario": {
            "rut": "1234567-8"
          }
        },
        {
          "fecha_prestamo": "2022-09-30T05:18:00.000Z",
          "fecha_devolucion": "2022-10-15T05:18:00.000Z",
          "fecha_devol_real": null,
          "lugar": "Casa",
          "ejemplar": {
            "id": "633671542436056ff7585878"
          },
          "comprobante": null,
          "usuario": {
            "rut": "1234567-8"
          }
        }
      ]
    }
  }

  export default prestamos;