const catalogo = {
    "data": {
      "getLibrosCatalogo": [
        {
          "id_libro": "633670ca2436056ff7585875",
          "titulo": "PRINCIPITO, EL",
          "autor": "DE SAINT-EXUPERY, ANTOINE",
          "editorial": "SALAMANDRA",
          "edicion": "Edición 2016",
          "anio": 1943,
          "categoria": "Literatura",
          "tipo": "Libro",
          "subtipo": "Clásicos Universales",
          "ejemplares_disponibles": 2,
          "ejemplares_sala": 0
        },
        {
            "id_libro": "633670ca2436056ff7585876",
            "titulo": "PRINCIPITO, EL",
            "autor": "DE SAINT-EXUPERY, ANTOINE",
            "editorial": "SALAMANDRA",
            "edicion": "Edición 2016",
            "anio": 1943,
            "categoria": "Literatura",
            "tipo": "Libro",
            "subtipo": "Clásicos Universales",
            "ejemplares_disponibles": 2,
            "ejemplares_sala": 0
          }
      ]
    }
  }

  export default catalogo;