const prestamos_casa = {
    "data": {
      "getPrestamosVencidos": [
        {
          "fecha_devolucion": "2022-10-15T05:18:00.000Z",
          "fecha_prestamo": "2022-09-30T05:18:00.000Z",
          "ejemplar": "633671542436056ff7585878",
          "duration": 27,
          "unit": "dias",
          "titulo": "PRINCIPITO, EL",
          "autor": "DE SAINT-EXUPERY, ANTOINE",
          "comprobante": "12345"
        }
      ]
    }
  }

export default prestamos_casa;