const ejemplares_sala_lectura = {
    "data": {
      "getEjemplaresByEstado": [
        {
          "id": "633671542436056fd7585879",
          "estado": "Sala Lectura"
        },
        {
          "id": "6336717c2436056fe7585876",
          "estado": "Sala Lectura"
        }
      ]
    }
  }
export default ejemplares_sala_lectura;