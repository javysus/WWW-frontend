const mis_prestamos = {
    "data": {
      "getPrestamosByUsuario": [
        {
          "comprobante": null,
          "ejemplar": {
            "id": "633671542436056ff7585878"
          },
          "fecha_devol_real": "2022-10-16T05:03:25.857Z",
          "fecha_devolucion": "2022-10-15T05:18:00.000Z",
          "fecha_prestamo": "2022-09-30T05:18:00.000Z",
          "lugar": "Casa"
        }
      ]
    }
  }
  
  export default mis_prestamos