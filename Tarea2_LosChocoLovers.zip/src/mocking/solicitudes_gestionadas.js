const solicitudes_gestionadas = {
    "data": {
      "getSolicitudesByBibliotecario": [
        {
          "libro": {
            "titulo": "PRINCIPITO, EL",
            "autor": "DE SAINT-EXUPERY, ANTOINE",
            "tipo": "Libro"
          },
          "fecha_reserva": "2022-09-30T02:00:00.000Z",
          "estado_solicitud": true,
          "lugar": "Sala"
        }
      ]
    }
  }
  
  export default solicitudes_gestionadas