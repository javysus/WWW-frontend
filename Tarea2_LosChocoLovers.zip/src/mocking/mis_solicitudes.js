const mis_solicitudes = {
    "data": {
      "getSolicitudesByUsuario": [
        {
          "libro": {
            "titulo": "PRINCIPITO, EL",
            "autor": "DE SAINT-EXUPERY, ANTOINE",
            "tipo": "Libro"
          },
          "lugar": "Sala Lectura",
          "fecha_reserva": "2022-09-30T02:00:00.000Z",
          "estado_solicitud": true
        }
      ]
    }
  }
  
  export default mis_solicitudes