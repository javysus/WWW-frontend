const ejemplares_casa = {
    "data": {
      "getEjemplaresByEstado": [
        {
          "id": "633671542436056fd7585878",
          "estado": "Casa"
        },
        {
          "id": "6336717c2436056fe758587c",
          "estado": "Casa"
        }
      ]
    }
  }
export default ejemplares_casa;