const ejemplares_disponibles = {
    "data": {
      "getEjemplaresByEstado": [
        {
          "id": "633671542436056ff7585878",
          "estado": "Disponible"
        },
        {
          "id": "6336717c2436056ff758587c",
          "estado": "Disponible"
        }
      ]
    }
  }

export default ejemplares_disponibles;