const ejemplares_sala_multimedia = {
    "data": {
      "getEjemplaresByEstado": [
        {
          "id": "633671542436056fd7584878",
          "estado": "Sala Multimedia"
        },
        {
          "id": "6336717c2436056fe748587c",
          "estado": "Sala Multimedia"
        }
      ]
    }
  }
export default ejemplares_sala_multimedia;